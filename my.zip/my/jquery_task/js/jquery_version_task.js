//jQuery 1.4
$(document).ready(function () {
    $("nav>ul>li>a").mouseenter(function () {
        var $this = $(this);
        $this.attr('title', $this.text());
        var myInterval = setInterval(function () {
            window.open('ad1', 'popupad', 'width=200,height=150')
            clearInterval(myInterval)
        }, 10000);
    });
});

//jQuery 1.6
$(document).ready(function () {
    $("img").hover(function () {
        var $this = $(this);
        $this.attr('title', $this.attr('src'));
        var myInterval = setInterval(function () {
            window.open('ad2', 'popupad', 'width=200,height=150')
            clearInterval(myInterval)
        }, 30000);
    });
});

//jQuery 3
$(document).ready(function(){
    $('footer > a').on("hover",function () {
        var $this = $(this);
        $this.attr('title', $this.attr('src'));
    });
    var myInterval = setInterval(function () {
        window.open('ad3', 'popupad', 'width=200,height=150')
        clearInterval(myInterval)
    }, 1000);
});

