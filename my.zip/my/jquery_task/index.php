<?php
/**
 * Created by PhpStorm.
 * User: eurocoders
 * Date: 10/30/2018
 * Time: 2:02 AM
 */
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>JQuery Task</title>
    <script src="https://code.jquery.com/jquery-1.4.min.js" type="application/javascript"></script>
    <script src="https://code.jquery.com/jquery-1.6.min.js" type="application/javascript"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/jquery_version_task.js" type="application/javascript"></script>
</head>
<body>
<nav>
    <ul>
        <li><a href="#home">Home</a></li>
        <li><a href="#contact">Contact</a></li>
        <li><a href="#about">About</a></li>
    </ul>
</nav>

<div class="gallery">
    <a target="_blank" href="images/img_5terre.jpg">
        <img src="images/img_5terre.jpg" alt="5Terre" width="600" height="400" title="Test">
    </a>
    <div class="desc">Add a description of the image here</div>
</div>

<div class="gallery">
    <a target="_blank" href="images/img_lights.jpg">
        <img src="images/img_lights.jpg" alt="Northern Lights" width="600" height="400" title="Test1">
    </a>
    <div class="desc">Add a description of the image here</div>
</div>

<div class="gallery">
    <a target="_blank" href="images/img_mountains.jpg">
        <img src="images/img_mountains.jpg" alt="Mountains" width="600" height="400" title="Test2">
    </a>
    <div class="desc">Add a description of the image here</div>
</div>
<div class="gallery">
    <a target="_blank" href="images/img_mountains.jpg">
        <img src="images/img_mountains.jpg" alt="Mountains" width="600" height="400" title="Test2">
    </a>
    <div class="desc">Add a description of the image here</div>
</div>
<div class="gallery">
    <a target="_blank" href="images/img_mountains.jpg">
        <img src="images/img_mountains.jpg" alt="Mountains" width="600" height="400" title="Test2">
    </a>
    <div class="desc">Add a description of the image here</div>
</div>
<footer>
    <a href="#" title="Footer!">Link</a>
</footer>
</body>
</html>