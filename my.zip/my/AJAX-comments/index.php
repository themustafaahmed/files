<?php
/**
 * Created by PhpStorm.
 * User: eurocoders
 * Date: 10/30/2018
 * Time: 1:41 AM
 */



$db = new PDO('mysql:host=localhost;dbname=comments', $user, $pass);