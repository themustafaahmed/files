$(function () {
    $(".submit-comment").on("click", function () {

        var comment = $("[name=comment]").val();
        var username = $("[name=username]").val();
        var url = "?comment="+comment+"&username="+username;

        $.ajax({
            // url : "comment-add.php",
            // data : str,
            type: "GET",
            url: "/comment/"+url,
            success: function () {
                console.log("comment saved");
            },
            error:function (xhr, textStatus, exceptionThrown) {
                alert(xhr.responseText);
            }
        });
    });
});

