<?php

error_reporting(E_ALL ^ E_NOTICE);
ini_set('display_errors', 1);
set_time_limit(0);
ini_set('max_execution_time', 0);

include 'cronConfig.php';
include_once($frameworkPath.'/core/Registry.php');

/**
 * Class PlayList
 */
class PlayList
{

    // Youtube Fetch holder
    protected $youtubeFetch;

    // Memcached holder
    protected $memcached;

    // Database holder
    protected $dbh;

    // Youtube Api Key holder
    protected $apiKey;

    private $model;

    /**
     * PlayList constructor.
     * @param $dbh
     * @param $siteSettings
     */
    function __construct($dbh, $siteSettings,$model)
    {
        // Youtube Fetch Holder
        $this->youtubeFetch = new Core\Packages\YoutubeFetch();

        // Set the Memcached holder
        $this->memcached = new Memcached();

        // Configuration memcached server
        $this->memcached->addServer("127.0.0.1", 11211);

        // Database holder
        $this->dbh = $dbh;

        // Youtube fetch Api Key holder
        $this->apiKey = $siteSettings['youtubeApiKeys'];

        // Model
        $this->model = $model;
    }

    /**
     * Init function getPlayList
     */
    public function getPlayList()
    {
        // Fetch the API keys
        $youtubeApiKeys = $this->apiKey;

        // Select a random key
        $apiKey = $youtubeApiKeys[rand(0, count($youtubeApiKeys) - 1)];

        $playlists = $this->dbh->fetchAll("SELECT * FROM playlist WHERE used ='0'");

        if (!$playlists) {
            echo "All Playlist Used!\n";
            return;
        }
        $playlist_printer = 0;
        foreach ($playlists as $playlist) {

            // Playlist Printer
            $playlist_printer++;
            echo "\033[33;35m" . "Playlist: " . $playlist_printer . "\033[0m\n";

            // Check cache for api playlist
            $youtube_fetch = $this->memcached->get('play_list_api' . $playlist['playlist']);

            // If it's empty
            if (empty($youtube_fetch)) {

                // Fetch data from API
                $youtube_fetch = $this->youtubeFetch->fetchPlaylistVideos($playlist['playlist']);

                // Set Cache with API data
                $this->memcached->set('play_list_api' . $playlist, $youtube_fetch, 86400);
            }

            $printer = 0;
            foreach ($youtube_fetch as $_youtube_id) {

                // Check youtube id whether it is not empty
                if (!empty($_youtube_id)) {

                    // Print Video number
                    $printer++;
                    echo "\033[33m" . "Video number: " . $printer . "\033[0m" . "\n";

                    // Check DB whether it is exist youtube id
                    //$video_id = $this->dbh->fetchRow("SELECT video_id FROM videos WHERE youtube_id = '" . $_youtube_id . "'");
                    //$video_id = $this->convertIntoNumber($_youtube_id);

                    $video_id = $this->model->convertIntoNumber($_youtube_id);

                    // If Db data empty
                    if (!empty($video_id)) {

                        // Fetch from Youtube
                        $videoInfo = $this->youtubeFetch->getVideoInfoApi($_youtube_id, $apiKey, false);

                        // Check getting data from Api it is array and not empty
                        if (is_array($videoInfo) && !empty($videoInfo)) {

                            // Configuration for insert data
                            $insertArray = array(
                                'youtube_id' => $videoInfo['id'],
                                'title' => $videoInfo['title'],
                                'duration' => $videoInfo['duration'],
                                'upload_date' => $videoInfo['upload_date'],
                                'uploader' => $videoInfo['uploader'],
                                'uploaderAvatar' => $videoInfo['uploaderAvatar'],
                                'end' => '0',
                                'start' => '0',
                                'status' => 'active',
                                'have_deals' => '0',
                                'views' => '0'
                            );

                            // Insert in DB
                            $update = $this->dbh->update('videos', $insertArray, 'video_id=' . $video_id);

                            // Check inserting success
                            if ($update) {
                                echo "\033[32m" . "Update successful" . "\033[0m\n";
                            } else {
                                echo "\033[31m" . "Update error" . "\033[0m\n";
                            }

                            print_r($insertArray);

                            // Sleep for 3 second
                            sleep(3);
                        }
                    }
                }
            }

            // $this->dbh->inlineDebug = true;
            $update = $this->dbh->Execute("UPDATE playlist SET used = '1' WHERE playlist='" . $playlist['playlist'] . "'");
            if ($update) {
                echo "\033[32m" . "Playlist Update successful" . "\033[0m\n";
            } else {
                echo "\033[31m" . "Playlist Update error" . "\033[0m\n";

            }
        }
    }

    /**
     * Init function printArray
     * @param $array
     */
    public function printArray($array)
    {
        echo "<pre>" . print_r($array, true) . "</pre>";
    }

    // For easy insert
    public function InsertPlaylist($playlist)
    {
        $check = $this->dbh->fetchOne("SELECT id FROM playlist WHERE playlist = :playlist", array('playlist' => $playlist));
        if ($check) {
            echo "Exist\n";
        } else {
            $insert = $this->dbh->insert('playlist', array('playlist' => $playlist, 'used' => '0'));
            if ($insert) {
                echo "\033[32m" . "Playlist Inserted successful" . "\033[0m\n";
            } else {
                echo "\033[31m" . "Playlist Insert error" . "\033[0m\n";
            }
        }
    }
}


// Load siteSettings Class
$siteSettings = Loader::loadConfig('siteSettings');

// Load Common Model
$model = Loader::LoadModel('Common');

// Init PlayList class
$list = new PlayList($dbh, $siteSettings,$model);

// For easy insert
//$list->InsertPlaylist('RDmmbroK0o2d0');

// Call function getPlayList
$list->getPlayList();
?>