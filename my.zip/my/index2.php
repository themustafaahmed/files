<!DOCTYPE html>
<head>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.0/clipboard.min.js"></script>
</head>
<a href="http://repeat.eurocoders.com//crons/fetchAmazon.php">Go to Repeat</a>
<br><br>
<form method="post">
    <label>Url</label>
    <input type="text" name="url" size="255">
    <br><br>
    <input type="submit" value="Fetch">
    <br><br>
</form>
</html>

<?php

class Index
{
    protected $imageSize;
    protected $bundle = array();

    public function replace()
    {
        $string = $_POST['url'];
        $word = 'tag=amairo-20&camp=1789';
        $replace = 'tag={{tag}}&camp={{camp}}';
        return str_replace($word, $replace, $string);
    }

    public function resizeImg()
    {
        $string = $this->imageSize;
        $word = '_SS500';
        $replace = '_SS100';
        return str_replace($word, $replace, $string);
    }

    public function getAsin()
    {
        $string = $_POST['url'];
        $url = parse_url($string);
        $word = array('/ref=as_li_tl', '/gp/product/');
        $replace = '';
        $url = str_replace($word, $replace, $url['path']);
        return $url;
    }

    public function getByAsing()
    {
        $_url = 'https://www.amazon.com/gp/product/' . $this->getAsin();
        $opts = array('http' => array('header' => "User-Agent: Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:47.0) Gecko/20100101 Firefox/47.0"));
        $context = stream_context_create($opts);
        $url = file_get_contents($_url, false, $context);
        @$doc = new DOMDocument();
        @$doc->loadHTML($url);
        $domXpath = new DOMXPath($doc);
        $title = $domXpath->query('//*[@class="a-size-large a-spacing-micro"]')->item(0);
        $author = $domXpath->query('//*[@class="a-size-medium a-link-normal"]')->item(0);
        $img = $domXpath->query('//div[@id="coverArt_feature_div"]/img')->item(0);
        $this->imageSize = $img->getAttribute('src');
        $songType = $domXpath->query('//div[@class="a-section a-spacing-none a-padding-none DigitalBuyButtonSection DigitalBuyButtonBuyBoxSection"]/span/span/a')->item(0);
        $type = '';
        if (strpos($songType->nodeValue, 'song')) {
            $type = 'song';
        } elseif (strpos($songType->nodeValue, 'Album')) {
            $type = 'album';
        }
        $this->bundle = [
            'title' => $title->nodeValue,
            'author' => $author->nodeValue,
            'type' => $type
        ];
    }

    public function bundle()
    {
        return $this->bundle;
    }

    public function fileGetContents($url)
    {
        $ch = curl_init();
        $user_agent = 'Mozilla/5.0 (Windows NT 6.1; rv:8.0) Gecko/20100101 Firefox/8.0';
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_AUTOREFERER, false);
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSLVERSION, CURL_SSLVERSION_DEFAULT);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $web_content = curl_exec($ch);
        $error = curl_error($ch);
        echo $error;
        curl_close($ch);
        return $web_content;
    }
}

$index = new Index();
if (!empty($_POST['url'])) {
    $index->getByAsing();
    $bundle = $index->bundle();
    echo '<form action="http://repeat.eurocoders.com/crons/fetchAmazon.php" method="post">';
    echo '<input size="255" name="title" value="' . $bundle['title'] . '">';
    echo '<br>';
    echo '<input size="255" name="type" value="' . $bundle['type'] . '">';
    echo '<br>';
    echo '<input size="255" name="author" value="' . $bundle['author'] . '">';
    echo '<br>';
    echo '<input size="255" name="asin" value="' . $index->getAsin() . '">';
    echo '<br>';
    echo '<input size="255" name="artwork" value="' . $index->resizeImg() . '">';
    echo '<br>';
    echo '<input size="255" name="url" value="' . $index->replace() . '">';
    echo '<br><br>';
    echo '<input  type="submit" value="Insert In DB">';
    echo '</form>';
}
?>

