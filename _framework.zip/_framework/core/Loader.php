<?php

spl_autoload_register("autoLoad");

function autoLoad($name)
{

    if (strpos($name, 'Core\Packages') !== false) {
        $path = str_replace('\\', DS, $name);
        $path = str_replace('Core' . DS . 'Packages' . DS, '', $path);
        $path = path('core_packages') . $path . DS . $path . '.php';
        if (file_exists($path)) {
            include_once($path);
        }

    } else if (strpos($name, 'Packages') !== false) {
        $path = str_replace('\\', DS, $name);
        $path = str_replace('Packages' . DS, '', $path);
        $path = path('packages') . $path . DS . $path . '.php';
        if (file_exists($path)) {
            include_once($path);
        }

    } else if (strpos($name, 'Imagine') !== false) {
        $path = str_replace('\\', '/', $name);
        $path = path('core_packages') . $path . '.php';
        if (file_exists($path)) {
            include_once($path);
        }
    }

}

class Loader
{

    // --------------------------------------------------------------
    // Helper
    // --------------------------------------------------------------
    public static function capitalize($string)
    {
        $strlen = mb_strlen($string, 'UTF-8');
        $firstChar = mb_substr($string, 0, 1, 'UTF-8');
        $then = mb_substr($string, 1, $strlen - 1, 'UTF-8');
        return mb_strtoupper($firstChar, 'UTF-8') . $then;
    }

    // --------------------------------------------------------------
    // Core
    // --------------------------------------------------------------
    public static function loadCore($file, $type, $folder = '')
    {

        if ($type == 'core') {
            $include_path = path('core') . $file . '.php';
        } elseif ($type == 'libs') {
            $include_path = path('core_libs') . $folder . DS . $file . '.php';
        } elseif ($type == 'package') {
            $include_path = path('core_packages') . $file . DS . $file . '.php';
        }

        if (is_file($include_path)) {
            include $include_path;
        } else {
            throw new \Exception($file . ' not found ' . $file, 1);
        }

    }

    // --------------------------------------------------------------
    // Project
    // --------------------------------------------------------------
    public static function loadConfig($file)
    {

        $include_path = path('config') . $file . '.php';

        if (is_file($include_path)) {
            return include $include_path;
        } else {
            throw new \Exception($type . ' not found ' . $file, 1);
        }

    }

    public static function loadModel($file, $init = true)
    {

        $modelName = self::capitalize($file) . 'Model';
        $include_path = path('models') . $modelName . '.php';

        if (is_file($include_path)) {

            include $include_path;
            if ($init) {
                return new $modelName();
            }

        } else {
            throw new \Exception($type . ' not found ' . $file, 1);
        }

    }

    public static function loadController($file, $folder = '')
    {

        $controllerName = self::capitalize($file) . 'Controller';
        $include_path = path('controllers');
        if ($folder) {
            $include_path .= $folder . '/';
        }
        $include_path .= $controllerName . '.php';

        if (is_file($include_path)) {

            include $include_path;
            return new $controllerName();

        } else {
            throw new \Exception($type . ' not found ' . $file, 1);
        }

    }

    public static function loadPackages($file)
    {

        $include_path = path('packages') . $file . DS . $file . '.php';

        if (is_file($include_path)) {
            include $include_path;
        } else {
            throw new \Exception($type . ' not found ' . $file, 1);
        }

    }

    // --------------------------------------------------------------
    // Deprecated
    // --------------------------------------------------------------
    // public static function load($file, $type, $folder = ''){

    // 	if($file == '') return;

    // 	if (is_array($file)){
    // 		foreach ($file as $_file){
    // 			self::load($_file, $type);
    // 		}
    // 		return;
    // 	}

    // 	if($type == 'model'){
    // 		$include_path = path('models'). self::capitalize($file) .'Model.php';
    // 	} elseif($type == 'packages'){
    // 		$include_path = path('packages'). $file .DS. $file .'.php';
    // 	} elseif ($type == 'config') {
    // 		$include_path = path('config'). $file .'.php';
    // 	} elseif ($type == 'lib') {
    // 		$include_path = path('lib').DS. $folder .DS. $file .'.php';
    // 	} elseif ($type == 'core') {
    // 		$include_path = path('core'). $file .'.php';
    // 	} elseif ($type == 'core_libs') {
    // 		$include_path = path('core_libs').$folder .DS. $file .'.php';
    // 	} elseif ($type == 'core_package') {
    // 		$include_path = path('core_packages'). $file .DS. $file .'.php';
    // 	}

    // 	if(is_file($include_path)){
    // 		if ($type == 'config') {
    // 			return include $include_path;
    // 		}
    // 		include $include_path;
    // 		if($type == 'model'){
    // 			$modelName  =self::capitalize($file) .'Model';
    // 			return new $modelName();
    // 		}

    // 	} else {
    // 		throw new \Exception($type.' not found '. $file, 1);
    // 	}

    // }

}

?>