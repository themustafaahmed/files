<?php

class Router
{

    const PARAM_REGEXP = '/^{((([^:]+):(.+))|(.+))}$/';
    const SEPARATOR_REGEXP = '/^[\s\/]+|[\s\/]+$/';
    private static $routes = array('childs' => array(), 'regexps' => array());
    private static $debug = false;

    private static function match($url, $urlReal)
    {
        $parts = explode('?', $url, 2);
        $parts = explode('/', preg_replace(self::SEPARATOR_REGEXP, '', $parts[0]));
        if (sizeof($parts) === 1 && $parts[0] === '') {
            $parts = array();
        }

        $partsReal = explode('?', $urlReal, 2);
        $partsReal = explode('/', preg_replace(self::SEPARATOR_REGEXP, '', $partsReal[0]));
        if (sizeof($partsReal) === 1 && $partsReal[0] === '') {
            $partsReal = array();
        }

        $params = array();
        $current = self::$routes;
        for ($i = 0, $length = sizeof($parts); $i < $length; $i++) {
            if (isset($current['childs'][$parts[$i]])) {
                $current = $current['childs'][$parts[$i]];
            } else {
                foreach ($current['regexps'] as $regexp => $route) {
                    if (preg_match('/^' . addcslashes($regexp, '/') . '$/', $parts[$i])) {
                        $current = $route;
                        $params[$current['name']] = $partsReal[$i];
                        continue 2;
                    }
                }

                if (!isset($current['others'])) {
                    return null;
                }

                $current = $current['others'];
                $params[$current['name']] = $partsReal[$i];
            }
        }
        if (!isset($current['methods'])) {
            return null;
        }

        return array(
            'methods' => $current['methods'],
            'route' => $current['route'],
            'params' => $params
        );
    }

    public static function addRoute($methods, $route, $handler)
    {
        $methods = (array)$methods;
        $parts = explode('/', preg_replace(self::SEPARATOR_REGEXP, '', $route));
        if (sizeof($parts) === 1 && $parts[0] === '') {
            $parts = array();
        }
        // $asd = self::$routes;
        $current =& self::$routes;
        for ($i = 0, $length = sizeof($parts); $i < $length; $i++) {
            $paramsMatch = preg_match(self::PARAM_REGEXP, $parts[$i], $paramsMatches);
            if ($paramsMatch) {
                if (!empty($paramsMatches[2])) {
                    if (!isset($current['regexps'][$paramsMatches[4]])) {
                        $current['regexps'][$paramsMatches[4]] = array(
                            'childs' => array(),
                            'regexps' => array(),
                            'name' => $paramsMatches[3]
                        );
                    }
                    $current =& $current['regexps'][$paramsMatches[4]];
                } else {
                    if (!isset($current['others'])) {
                        $current['others'] = array(
                            'childs' => array(),
                            'regexps' => array(),
                            'name' => $paramsMatches[5]
                        );
                    }
                    $current =& $current['others'];
                }
            } else {
                if (!isset($current['childs'][$parts[$i]])) {
                    $current['childs'][$parts[$i]] = array(
                        'childs' => array(),
                        'regexps' => array()
                    );
                }
                $current =& $current['childs'][$parts[$i]];
            }
        }
        $current['route'] = $route;
        for ($i = 0, $length = sizeof($methods); $i < $length; $i++) {
            if (!isset($current['methods'])) {
                $current['methods'] = array();
            }
            $current['methods'][strtoupper($methods[$i])] = $handler;
        }
    }

    public static function dispatch($method, $url, $urlReal)
    {
        $route = self::match($url, $urlReal);
        if (!$route) {

            return array(
                'error' => array(
                    'code' => 404,
                    'message' => 'Not Found'
                ),
                'method' => $method,
                'url' => $url
            );
        }

        if (isset($route['methods'][$method])) {
            return array(
                'method' => $method,
                'url' => $url,
                'route' => $route['route'],
                'params' => $route['params'],
                'handler' => $route['methods'][$method]
            );
        }

        return array(
            'error' => array(
                'code' => 405,
                'message' => 'Method Not Allowed'
            ),
            'method' => $method,
            'url' => $url,
            'route' => $route['route'],
            'params' => $route['params'],
            'allowed' => array_keys($route['methods'])
        );
    }

    public static function getUri()
    {
        return $_SERVER['REQUEST_URI'];
    }

    public static function currentUri()
    {
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
        return $protocol . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    }

    public static function capitalize($string)
    {
        $strlen = mb_strlen($string, 'UTF-8');
        $firstChar = mb_substr($string, 0, 1, 'UTF-8');
        $then = mb_substr($string, 1, $strlen - 1, 'UTF-8');
        return mb_strtoupper($firstChar, 'UTF-8') . $then;
    }

    public static function run()
    {

        $siteSettings = Registry::get('siteSettings');
        $adminFolder = '';
        if (isset($siteSettings['adminFolder'])) {
            $adminFolder = $siteSettings['adminFolder'];
        }

        $request = str_replace($adminFolder, '', strtolower($_SERVER['REQUEST_URI']));
        $requestReal = str_replace($adminFolder, '', $_SERVER['REQUEST_URI']);
        $debugSettings = Registry::get('debugSettings');

        if (is_array($debugSettings)) {
            if ($debugSettings['router_debug'] == true) {
                if (in_array($_SERVER['REMOTE_ADDR'], $debugSettings['ips'])) {
                    self::$debug = true;
                }
            }
        }

        // it will return only rules matching the request method :)
        $rules = Loader::loadConfig('routerSettings');
        $method = strtoupper($_SERVER['REQUEST_METHOD']);

        if (count($rules) > 0) {
            foreach ($rules as $key => $value) {
                self::addRoute($method, $key, $value);
            }
        } else {
            self::Redirect();
        }

        $result = self::dispatch($method, $request, $requestReal);
        if (self::$debug == true) {
            self::prettyPrint($result);
            if ($debugSettings['should_stop_after_result'] == true) {
                die;
            }
        }

        if (!isset($result['error'])) {
            $controller = $result['handler']['controller'];
            $action = $result['handler']['action'];
            $folder = $result['handler']['folder'];
            $isAuth = $result['handler']['auth'];

            if ($isAuth) {

                $authKey = $siteSettings['authKey'];
                if (!isset($_SESSION[$authKey])) {
                    self::Redirect('/auth/login');
                }

            }

            if (is_array($debugSettings)) {
                if ($debugSettings['router_dev'] == true) {
                    if (in_array($_SERVER['REMOTE_ADDR'], $debugSettings['ips'])) {
                        $controller = $result['handler']['dev_controller'] ? $result['handler']['dev_controller'] : $result['handler']['controller'];
                        $action = $result['handler']['dev_action'] ? $result['handler']['dev_action'] : $result['handler']['action'];
                    }

                }

            }

            $controller = self::capitalize($controller) . 'Controller';
            $action = 'action_' . strtolower($action);

            $params = $result['params'];

            if ($folder) {
                $controllerPath = path('controllers') . $folder . '/' . $controller . '.php';
            } else {
                $controllerPath = path('controllers') . $controller . '.php';
            }
            if (file_exists($controllerPath)) {

                Registry::set($params, 'param');

                include $controllerPath;

                $controllerObject = new $controller;
                if (method_exists($controllerObject, $action)) {
                    if (method_exists($controllerObject, 'init')) {
                        $controllerObject->init();
                    }
                    $controllerObject->{$action}();
                } else {
                    self::Redirect();
                }

            } else {
                self::Redirect();
            }

        } else {

            self::Redirect();
        }

    }

    private static function prettyPrint($array)
    {
        echo '<pre>' . print_r($array, true) . '</pre>';
    }

    public static function Redirect($url = false)
    {

        if ($url) {
            $siteSettings = Registry::get('siteSettings');
            $url = $siteSettings['url'] . $url;
        } else {
            $siteSettings = Registry::get('siteSettings');
            if ($siteSettings['not_found']) {
                $url = $siteSettings['not_found'];
            } else {
                $url = $siteSettings['url'];
            }
        }

        // Check if headers are sent
        if (!headers_sent()) {
            header('Location: ' . $url);

            // If the headers are sent - redirect via JavaScript
        } else {
            echo '<script type="text/javascript">';
            echo 'window.location.href="' . $url . '";';
            echo '</script>';
            echo '<noscript>';
            echo '<meta http-equiv="refresh" content="0;url=' . $url . '" />';
            echo '</noscript>';
        }

        // Terminate
        exit();
    }

}

?>