<?php

// --------------------------------------------------------------
// Define the directory separator for the environment.
// --------------------------------------------------------------
if (!defined('DS')) define('DS', DIRECTORY_SEPARATOR);

// --------------------------------------------------------------
// Change the application folder (excuted from cron).
// --------------------------------------------------------------
if (empty($appPath)) {
    $workspace_path = realpath('') . DS;
} else {
    $workspace_path = $appPath . DS;
}

$up = '';
if (defined('adminEnv')) {
    $up = '../';
}
// --------------------------------------------------------------
// Define the path to the base directory.
// --------------------------------------------------------------
$GLOBALS['project_paths']['core'] = realpath($workspace_path . $up . '../_framework') . DS;

// --------------------------------------------------------------
// Define the path to the base directory.
// --------------------------------------------------------------
$GLOBALS['project_paths']['core_packages'] = realpath($workspace_path . $up . '../_framework') . '/packages' . DS;

// --------------------------------------------------------------
// Define the path to the base directory.
// --------------------------------------------------------------
$GLOBALS['project_paths']['core_libs'] = realpath($workspace_path . $up . '../_framework') . '/libs' . DS;

// --------------------------------------------------------------
// Define the path to the base directory.
// --------------------------------------------------------------
$GLOBALS['project_paths']['base'] = $workspace_path;

// --------------------------------------------------------------
// The path to the public directory.
// --------------------------------------------------------------
$GLOBALS['project_paths']['public'] = $workspace_path . 'public' . DS;

// --------------------------------------------------------------
// The path to the lib directory.
// --------------------------------------------------------------
$GLOBALS['project_paths']['libs'] = $workspace_path . 'libs' . DS;

// --------------------------------------------------------------
// The path to the controllers directory.
// --------------------------------------------------------------
$GLOBALS['project_paths']['controllers'] = $workspace_path . 'controllers' . DS;

// --------------------------------------------------------------
// The path to the templates directory.
// --------------------------------------------------------------
$GLOBALS['project_paths']['templates'] = $workspace_path . 'templates' . DS;

// --------------------------------------------------------------
// The path to the templates directory.
// --------------------------------------------------------------
$GLOBALS['project_paths']['templates_c'] = $workspace_path . 'templates_c' . DS;

// --------------------------------------------------------------
// The path to the tasks directory.
// --------------------------------------------------------------
$GLOBALS['project_paths']['tasks'] = $workspace_path . 'tasks' . DS;

// --------------------------------------------------------------
// The path to the models directory.
// --------------------------------------------------------------
$GLOBALS['project_paths']['models'] = $workspace_path . 'models' . DS;

// --------------------------------------------------------------
// The path to the config directory.
// --------------------------------------------------------------
$GLOBALS['project_paths']['config'] = $workspace_path . 'config' . DS;

// --------------------------------------------------------------
// The path to the packages directory.
// --------------------------------------------------------------
$GLOBALS['project_paths']['packages'] = $workspace_path . 'packages' . DS;

// --------------------------------------------------------------
// The path to the images directory.
// --------------------------------------------------------------
$GLOBALS['project_paths']['images'] = $workspace_path . 'public' . DS . 'img' . DS;

/**
 * A global path helper function.
 *
 * <code>
 *     $storage = path('sys');
 * </code>
 *
 * @param  string $path
 * @return string
 */
function path($path)
{
    return $GLOBALS['project_paths'][$path];
}

function getPaths()
{
    return $GLOBALS['project_paths'];
}

?>