<?php

/**
 * Base Controller for Grape Framework
 *
 **/

class BaseController
{

    public $site_config;
    public $getParam;
    public $dbh;

    public function __construct()
    {
        $this->smarty = Registry::get('smarty');
        $this->siteSettings = Registry::get('siteSettings');
        $this->getParam = Registry::get('param');
        $this->dbh = Registry::get('dbh');
        $this->memcached = Registry::get('memcached');
    }

    // Redirecting method
    public static function redirect($url)
    {

        // Chech if some headers are sent
        if (!headers_sent()) {
            header('Location: ' . $url);

            // If the headers are sent - redirect via JavaScript
        } else {
            echo '<script type="text/javascript">';
            echo 'window.location.href="' . $url . '";';
            echo '</script>';
            echo '<noscript>';
            echo '<meta http-equiv="refresh" content="0;url=' . $url . '" />';
            echo '</noscript>';
        }

        // Terminate
        exit();
    }

    public function prettyPrint($array)
    {
        echo '<pre>' . print_r($array, true) . '</pre>';
    }

    public function generateFormToken($form)
    {

        // generate a token from an unique value
        $token = md5(uniqid(microtime(), true));

        // Write the generated token to the session variable to check it against the hidden field when the form is sent
        $_SESSION[$form . '_token'] = $token;

        return $token;

    }

    public function verifyFormToken($form)
    {

        // check if a session is started and a token is transmitted, if not return an error
        if (!isset($_SESSION[$form . '_token'])) {
            return false;
        }

        // check if the form is sent with token in it
        if (!isset($_POST['token'])) {
            return false;
        }

        // compare the tokens against each other if they are still the same
        if ($_SESSION[$form . '_token'] !== $_POST['token']) {
            return false;
        }

        return true;
    }

    public function returnErrors($validationRules)
    {

        $errors = array();
        if (!empty($validationRules)) {

            foreach ($validationRules as $field => $fieldData) {

                foreach ($fieldData as $fieldDataChild) {

                    if (isset($fieldDataChild['rule'])) {
                        if ($fieldDataChild['rule'] == 'validEmail') {
                            $fieldDataChild['pattern'] = '^[a-z0-9]+([_+\\.-][a-z0-9]+)*@([a-z0-9]+([\.-][a-z0-9]+)*)+\\.[a-z]{2,}$';
                        }

                        if ($fieldDataChild['rule'] == 'notEmpty') {
                            $fieldDataChild['pattern'] = '[\s\S]';
                        }
                    }

                    if ($fieldDataChild['pattern'] != "[\s\S]") {

                        if ($fieldDataChild['rule'] == 'validEmail') {
                            if (!preg_match("/" . $fieldDataChild['pattern'] . "/", $fieldDataChild['value'])) {
                                $errors[$field] = array('reason' => $fieldDataChild['msg']);
                                break;
                            }
                        } else {

                            if (preg_match("/" . $fieldDataChild['pattern'] . "/", $fieldDataChild['value'])) {
                                $errors[$field] = array('reason' => $fieldDataChild['msg']);
                                break;
                            }
                        }

                    } else {

                        if (preg_match("/[\s\S]/", $fieldDataChild['value']) == false) {
                            $errors[$field] = array('reason' => $fieldDataChild['msg']);
                            break;
                        }

                    }
                }

            }

        }

        return $errors;

    }

}

?>