<?php

/**
 *  DB - A simple database class
 *
 * @git         https://github.com/wickyaswal/PHP-MySQL-PDO-Database-Class
 *
 */

class Database
{

    private static $_instance = null;

    # @array, The debug array
    public $debug;

    # @object, The PDO object
    private $pdo;

    # @object, PDO statement object
    private $sQuery;

    # @array,  The database settings
    private $settings;

    # @bool ,  Is the debugger active?
    public $debugger = false;

    public $inlineDebug = false;

    # @bool ,  Connected to the database
    private $bConnected = false;

    # @array, The parameters of the SQL query
    private $parameters;

    /**
     *   Default Constructor
     *
     *   1. Instantiate Log class.
     *   2. Connect to database.
     *   3. Creates the parameter array.
     */
    public function __construct($database)
    {
        $this->settings = $database;
        $this->Connect();
        $this->parameters = array();
        $this->debug = array();
    }

    public static function getInstance($database)
    {
        if (self::$_instance == null) {
            self::$_instance = new Database($database);
        }
        return self::$_instance;
    }

    /**
     *   This method makes connection to the database.
     *
     *   1. Reads the database settings from a ini file.
     *   2. Puts  the ini content into the settings array.
     *   3. Tries to connect to the database.
     *   4. If connection failed, exception is displayed.
     */
    private function Connect()
    {

        if (isset($this->settings['connection_uri_socket'])) {
            $dsn = $this->settings['connection_uri_socket'];
        } else {
            $dsn = $this->settings['connection_uri'];
        }

        try {

            $encode = $this->settings['encode'] ? $this->settings['encode'] : 'UTF8';

            # Read settings from INI file, set UTF8
            $this->pdo = new \PDO($dsn, $this->settings['username'], $this->settings['password'], array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES " . $encode));

            # We can now log any exceptions on Fatal error. 
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            # Disable emulation of prepared statements, use REAL prepared statements instead.
            $this->pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

            # Connection succeeded, set the boolean to true.
            $this->bConnected = true;

        } catch (PDOException $e) {
            # Write into log
            // if (!empty($this->debugger)){
            $this->ExceptionLog($e->getMessage());
            // }
            die();
        }
    }

    /*
    *   You can use this little method if you want to close the PDO connection
    */
    public function CloseConnection()
    {

        # Set the PDO object to null to close the connection
        # http://www.php.net/manual/en/pdo.connections.php
        $this->pdo = null;
    }

    /*
    *   returns Raw SQL
    */
    public function pdo_sql_debug_($sql, $parameters)
    {

        if (empty($parameters)) {
            $parameters = $this->parameters;
        }

        if (!empty($parameters)) {
            foreach ($parameters as $column => $param) {
                $placeholders[':' . $column] = $param;
            }

            foreach ($placeholders as $k => $v) {
                $sql = str_replace($k, $v, $sql);
            }
            return $sql;
        } else {
            return $sql;
        }

    }

    /**
     *   Every method which needs to execute a SQL query uses this method.
     *
     *   1. If not connected, connect to the database.
     *   2. Prepare Query.
     *   3. Parameterize Query.
     *   4. Execute Query.
     *   5. On exception : Write Exception into the log + SQL query.
     *   6. Reset the Parameters.
     */
    private function Init($query, $parameters = "")
    {

        # Connect to database
        if (!$this->bConnected) {
            $this->Connect();
        }
        try {

            if ($this->inlineDebug) {
                echo '<p style="border-bottom: 1px solid #ccc;margin-bottom: 20px;padding: 10px;">';
                echo $this->pdo_sql_debug_($query, $parameters);
                echo '</p>';
            }

            if (!empty($this->debugger)) {

                $this->debug = array();

                $this->debug['debugQuery'] = $this->pdo_sql_debug_($query, $parameters);


                $this->debug['start'] = microtime(true);
                $this->debug['start_memory'] = memory_get_usage(true);
            }

            # Prepare query
            $this->sQuery = $this->pdo->prepare($query);

            # Add parameters to the parameter array 
            $this->bindMore($parameters);

            # Bind parameters
            if (!empty($this->parameters)) {
                foreach ($this->parameters as $param => $value) {
                    if (is_int($value[1])) {
                        $type = PDO::PARAM_INT;
                    } else if (is_bool($value[1])) {
                        $type = PDO::PARAM_BOOL;
                    } else if (is_null($value[1])) {
                        $type = PDO::PARAM_NULL;
                    } else {
                        $type = PDO::PARAM_STR;
                    }
                    // Add type when binding the values to the column
                    $this->sQuery->bindValue($value[0], $value[1], $type);
                }
            }

            # Execute SQL 
            $this->success = $this->sQuery->execute();

        } catch (PDOException $e) {

            if ($this->inlineDebug) {
                echo $this->ExceptionLog($e->getMessage());
            }

            // If the debugger is on - add the time and the query
            if (!empty($this->debugger)) {
                $debugQuery = $this->pdo_sql_debug_($query, $parameters);
                $this->debugger_data[] = array('memory' => 0, 'time' => 0, 'query' => $this->ExceptionLog($e->getMessage(), $debugQuery), 'status' => 'error');
            }

        }

        # Reset the parameters
        $this->parameters = array();
    }


    private function afterFetch()
    {
        // If the debugger is on - add the time and the query
        if (!empty($this->debugger)) {
            $this->debug['end'] = microtime(true);
            $this->debug['end_memory'] = memory_get_usage(true);

            $this->debugger_data[] = array('memory' => $this->debug['end_memory'] - $this->debug['start_memory'], 'time' => round($this->debug['end'] - $this->debug['start'], 4), 'query' => $this->debug['debugQuery'], 'status' => 'normal');
        }
    }

    /**
     * @void
     *
     *   Add the parameter to the parameter array
     * @param string $para
     * @param string $value
     */
    public function bind($para, $value)
    {
        // $this->parameters[sizeof($this->parameters)] = ":" . $para . "\x7F" . utf8_encode($value);
        // $this->parameters[sizeof($this->parameters)] = ":" . $para . "\x7F" . $value;
        // $this->parameters[sizeof($this->parameters)] = [":" . $para , $value];
        $this->parameters[sizeof($this->parameters)] = array(":" . $para, $value);
    }

    /**
     *   $db->bindMore(array("firstname"=>"John","age"=>"19"));
     *
     * @void
     *
     *   Add more parameters to the parameter array
     * @param array $parray
     */
    public function bindMore($parray)
    {
        if (empty($this->parameters) && is_array($parray)) {
            $columns = array_keys($parray);
            foreach ($columns as $i => &$column) {
                $this->bind($column, $parray[$column]);
            }
        }
    }

    /**
     *   $db->bindMore(array("firstname"=>"John","age"=>"19"));
     *
     * @void
     *
     *   Add more parameters to the parameter array
     * @param array $parray
     */
    public function Execute($query, $params = null, $fetchmode = PDO::FETCH_ASSOC)
    {
        $query = trim($query);
        $this->Init($query, $params);
        if ($this->success) {

            try {
                $this->afterFetch();
                $this->sQuery->closeCursor(); // Frees up the connection to the server so that other SQL statements may be issued 
                return $this->sQuery->rowCount();
            } catch (PDOException $e) {

                // If the debugger is on - add the time and the query
                if (!empty($this->debugger)) {
                    $this->debugger_data[] = array('memory' => 0, 'time' => 0, 'query' => $this->ExceptionLog($e->getMessage(), $this->debug['debugQuery']), 'status' => 'error');
                }

            }
        }
        return false;
    }

    /**
     *   If the SQL query  contains a SELECT or SHOW statement it returns an array containing all of the result set row
     *   If the SQL statement is a DELETE, INSERT, or UPDATE statement it returns the number of affected rows
     *
     *   $db->single("SELECT firstname FROM Persons WHERE Id = :id ", array('id' => '3' ) );
     *
     * @param  string $query
     * @param  array $params
     * @param  int $fetchmode
     * @return mixed
     */
    public function fetchAll($query, $params = null, $fetchmode = PDO::FETCH_ASSOC)
    {
        $query = trim($query);
        $this->Init($query, $params);
        if ($this->success) {

            try {
                $result = $this->sQuery->fetchAll($fetchmode);
                $this->afterFetch();
                $this->sQuery->closeCursor(); // Frees up the connection to the server so that other SQL statements may be issued 
                return $result;
            } catch (PDOException $e) {

                // If the debugger is on - add the time and the query
                if (!empty($this->debugger)) {
                    $this->debugger_data[] = array('memory' => 0, 'time' => 0, 'query' => $this->ExceptionLog($e->getMessage(), $this->debug['debugQuery']), 'status' => 'error');
                }

            }
        }
        return false;

    }

    /**
     *   Returns an array which represents a row from the result set
     *
     * @param  string $query
     * @param  array $params
     * @param  int $fetchmode
     * @return array
     */
    public function fetchRow($query, $params = null, $fetchmode = PDO::FETCH_ASSOC)
    {
        $this->Init($query, $params);
        if ($this->success) {
            try {
                $result = $this->sQuery->fetch($fetchmode);
                $this->afterFetch();
                $this->sQuery->closeCursor(); // Frees up the connection to the server so that other SQL statements may be issued 
                return $result;
            } catch (PDOException $e) {

                // If the debugger is on - add the time and the query
                if (!empty($this->debugger)) {
                    $this->debugger_data[] = array('memory' => 0, 'time' => 0, 'query' => $this->ExceptionLog($e->getMessage(), $this->debug['debugQuery']), 'status' => 'error');
                }

            }
        }
        return false;
    }

    /**
     *   Returns the value of one single field/column
     *
     * @param  string $query
     * @param  array $params
     * @return string
     */
    public function fetchOne($query, $params = null)
    {

        $this->Init($query, $params);
        if ($this->success) {
            try {
                $result = $this->sQuery->fetchColumn();
                $this->afterFetch();
                $this->sQuery->closeCursor(); // Frees up the connection to the server so that other SQL statements may be issued
                return $result;
            } catch (PDOException $e) {

                // If the debugger is on - add the time and the query
                if (!empty($this->debugger)) {
                    $this->debugger_data[] = array('memory' => 0, 'time' => 0, 'query' => $this->ExceptionLog($e->getMessage(), $this->debug['debugQuery']), 'status' => 'error');
                }

            }
        }
        return false;
    }

    /**
     *   Returns an array which represents a column from the result set
     *
     * @param  string $query
     * @param  array $params
     * @return array
     */
    public function column($query, $params = null)
    {

        $this->Init($query, $params);
        if ($this->success) {

            try {
                $Columns = $this->sQuery->fetchAll(PDO::FETCH_NUM);

                $column = array();
                foreach ($Columns as $cells) {
                    $column[] = $cells[0];
                }
                $this->afterFetch();
                return $column;
            } catch (PDOException $e) {

                // If the debugger is on - add the time and the query
                if (!empty($this->debugger)) {
                    $this->debugger_data[] = array('memory' => 0, 'time' => 0, 'query' => $this->ExceptionLog($e->getMessage(), $this->debug['debugQuery']), 'status' => 'error');
                }

            }
        }

    }

    /**
     *   Returns the number of affected rows
     *
     * @param  string $table
     * @param  array $params
     * @param  int $fetchmode
     * @return mixed
     */
    public function insert($table, $params = null)
    {

        foreach ($params as $col => $val) {
            $this->bind($col, $val);
            $cols[] = $col;
            $vals[] = ':' . $col;
        }

        $query = 'INSERT INTO ' . $table . ' (' . implode(', ', $cols) . ')  VALUES (' . implode(', ', $vals) . ')';

        $this->Init($query, $params);

        if ($this->success) {
            try {
                $this->afterFetch();
                return $this->sQuery->rowCount();
            } catch (PDOException $e) {

                // If the debugger is on - add the time and the query
                if (!empty($this->debugger)) {
                    $this->debugger_data[] = array('memory' => 0, 'time' => 0, 'query' => $this->ExceptionLog($e->getMessage(), $this->debug['debugQuery']), 'status' => 'error');
                }

            }
        }
        return false;

    }

    /**
     *   Returns the number of affected rows
     *
     * @param  string $table
     * @param  array $params
     * @param  string $where
     * @param  int $fetchmode
     * @return mixed
     */
    public function update($table, $params = null, $where = false)
    {

        foreach ($params as $col => $val) {
            $this->bind($col, $val);
            $update_array[] = $col . ' = :' . $col;
        }

        $update_string = implode(', ', $update_array);
        if ($where) {
            // if(is_array($where)){
            //     foreach ($where as $whereCol => $whereVal) {

            //         $tempWhereCol = str_replace('>', '', $whereCol);
            //         $tempWhereCol = str_replace('<', '', $tempWhereCol);
            //         $tempWhereCol = trim($tempWhereCol);

            //         $this->bind('where_'.$tempWhereCol.'_where', $whereVal);
            //         if(strpos($whereCol, '<') !== false){
            //             $where_array[] = $whereCol.' :where_'.$tempWhereCol.'_where';
            //         } else if(strpos($whereCol, '>') !== false){
            //             $where_array[] = $whereCol.' :where_'.$tempWhereCol.'_where';
            //         } else {
            //             $where_array[] = $whereCol.' = :where_'.$tempWhereCol.'_where';
            //         }

            //     }

            //     $where = implode('AND ', $where_array);
            // }
            $query = 'UPDATE ' . $table . " SET " . $update_string . " WHERE " . $where;
        } else {
            $query = 'UPDATE ' . $table . " SET " . $update_string;
        }

        $this->Init($query, $params);

        if ($this->success) {
            $this->afterFetch();
            return $this->sQuery->rowCount();
        }
        return false;

    }

    /**
     *  Returns the last inserted id.
     * @return string
     */
    public function lastInsertId()
    {
        return $this->pdo->lastInsertId();
    }

    /**
     * Writes the log and returns the exception
     *
     * @param  string $message
     * @param  string $sql
     * @return string
     */
    private function ExceptionLog($message, $sql = "")
    {
        $exception = 'Unhandled Exception. <br />';
        $exception .= $message;
        $exception .= "<br /> You can find the error back in the log.";
        if (!empty($sql)) {
            # Add the Raw SQL to the Log
            $exception .= "<br/><br/>Raw SQL : " . $sql;
        }

        return $exception;
    }

    // MySQL debugger - show queryies in the footer
    public function showSQLDebugger()
    {

        // Check if the debugger is on
        if (!empty($this->debugger) && count($this->debugger_data) > 0) {

            // Form the main table
            $return = '';
            $return .= '<style type="text/css">' . file_get_contents(path('core') . 'css/debugger.css') . '</style>';

            $return .= '
                <div class="debugger_warp">
                <div class="debugger_body">
                    <div class="debugger_main de-bold" style="text-align:center;">Query Debug Information</div>

                    <table class="debugger_main">
                        <thead>
                            <tr>
                                <td class="de-align-center de-column1">Num</td>
                                <td class="de-align-center de-left_border de-column2">Query</td>
                                <td class="de-align-center de-left_border de-column3">Time</td>';
            $return .= '<td class="de-align-center de-left_border de-column4">Memory</td>';
            $return .= '</tr>
                        </thead>';

            // Store all queries time
            $time = 0;
            $all = 0;

            // Add queries data
            foreach ($this->debugger_data as $key => $value) {

                if ($value['memory'] < 0) $value['memory'] = 0;

                $return .= '
                    <tr>
                        <td class="de-align-center de-column1">' . $key . '</td>
                        <td class="de-left_border de-column2 ' . $value['status'] . '">' . $value['query'] . '</td>
                        <td class="de-align-center de-left_border de-column3">' . $value['time'] . '</td>';
                $return .= '<td class="de-align-center de-left_border de-column4" title="' . $value['memory'] . 'bytes" alt="' . $value['memory'] . 'bytes">' . round($value['memory'] / 1000, 2) . 'kB</td>';

                $return .= '</tr>';

                $time += $value['time'];
                $memory += $value['memory'];
                $all++;
            }

            $return .= '
                <tr class="de-total">
                    <td class="de-align-center de-border_bottom_none de-column1"></td>
                    <td class="de-left_border de-bold de-border_bottom_none de-column2"> Total </td>
                    <td class="de-align-center de-left_border de-bold de-border_bottom_none de-column3">' . $time . '</td>';
            $return .= '<td class="de-align-center de-left_border de-bold de-border_bottom_none de-column4" title="' . $value['memory'] . 'bytes" alt="' . $value['memory'] . 'bytes">' . round($memory / 1000, 2) . 'kB</td>';
            $return .= '</tr>';

            // Show the SQL debugger
            echo $return . "</table></div></div>";
        }
    }

}

?>
