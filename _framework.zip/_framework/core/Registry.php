<?php

class Registry
{

    // Storage
    public static $register = array();

    // Set value
    public static function set($var, $name = '')
    {
        self::$register[$name] = $var;
    }

    // Get value
    public static function get($name)
    {
        return self::$register[$name];
    }

    // Check value
    public static function isRegister($name)
    {
        return array_key_exists($name, self::$register);
    }

}

?>
