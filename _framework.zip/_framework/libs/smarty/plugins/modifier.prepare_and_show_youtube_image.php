<?php

    function smarty_modifier_prepare_and_show_youtube_image($youtube_id, $size, $thumbnail, $imgUrl) {

        if(empty($size)){
            $size = '207x120';
        }

        $imageName =  $youtube_id.'.jpg';
        if(file_exists(path('public').'img/thumbs/'.$imageName) === false){

            $imageData = file_get_contents($thumbnail);

            file_put_contents(path('public').'img/thumbs_orig/'.$imageName, $imageData);
            chmod(path('public').'img/thumbs_orig/'.$imageName, 0777);

            $command = '/usr/bin/convert '.path('public').'img/thumbs_orig/'.$imageName.' -resize '.$size.' -strip -quality 85 -interlace JPEG '.path('public').'img/thumbs/'.$imageName;

            exec($command);
            if(file_exists(path('public').'img/thumbs/'.$imageName) === true){
                unlink(path('public').'img/thumbs_orig/'.$imageName);
                return $imgUrl.'/thumbs/'.$imageName;
            } else {
                return 'https://i.ytimg.com/vi/'.$youtube_id.'/maxresdefault.jpg';
            }

        } else {
            return $imgUrl.'/thumbs/'.$imageName;
        }

    }

?>