<?php
    function smarty_modifier_loadJs($params) {

        $js_content = '<script type="text/javascript">/* '.$params.' */'."\r\n";
        $filePath = path('public').$params;
        if (file_exists($filePath)) {
            $js_processed = file_get_contents($filePath);
        } else {
            $js_processed = ".wrong{}";
        }
        $js_content .= $js_processed;
        $js_content .= '</script>';
        return $js_content;
    }
?>