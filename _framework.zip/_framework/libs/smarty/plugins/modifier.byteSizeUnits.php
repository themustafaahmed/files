<?php

/**
 * Smarty plugin
 *
 * @package    Smarty
 * @subpackage PluginsModifier
 */

/**
 * Smarty bytes modifier plugin
 * Type:     modifier<br>
 * Name:     byteSizeUnits<br>
 * Purpose:  Convert bytes to human friendly units
 *
 * @author Marian Petrov <war1an91 at gmail dot com>
 *
 * @param integer  $bytes      input bytes
 * @param string $type      decimal or binary
 *
 * @return string converted units
 */
function smarty_modifier_byteSizeUnits($bytes, $type = 'decimal'){

    if($type == 'binary'){
        $GB = 1073741824;
        $MB = 1048576;
        $KB = 1024;
    } else {
        $GB = 1000000000;
        $MB = 1000000;
        $KB = 1000;
    }

    if ($bytes >= $GB){
        $bytes = number_format($bytes / $GB, 2) . ' GB';
    } elseif ($bytes >= $MB) {
        $bytes = number_format($bytes / $MB, 2) . ' MB';
    } elseif ($bytes >= $KB) {
        $bytes = number_format($bytes / $KB, 2) . ' KB';
    } elseif ($bytes > 1){
        $bytes = $bytes . ' bytes';
    } elseif ($bytes == 1){
        $bytes = $bytes . ' byte';
    } else {
        $bytes = '0 bytes';
    }

    return $bytes;

}