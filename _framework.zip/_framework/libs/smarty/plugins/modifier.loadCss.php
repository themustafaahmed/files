<?php
function smarty_modifier_loadCss($params, $url) {

  $css_content = '<style type="text/css">/* '.$params.' */'."\r\n";
  $filePath = path('public').$params;
  if (file_exists($filePath)) {
    $css_processed = file_get_contents($filePath);
    $css_processed = str_replace("../fonts/", $url."/public/fonts/", $css_processed);
    $css_processed = str_replace("../img/", $url."/public/img/", $css_processed);
  } else {
    $css_processed = ".wrong{}";
  }

  $css_content .= $css_processed;
  $css_content .= '</style>';

  return $css_content;
}
?>