<?php
function smarty_modifier_shortNumberFormat($n) {

  if ($n <= 999) {
    // 0 - 900
    $n_format = $n;
    $suffix = '';
  } else if ($n <= 999999) {
    // 0.9k-850k
    $n_format = floor($n / 100)/10;
    $suffix = 'k';
  } else if ($n <= 99999999) {
    // 0.9m-850m
    $n_format = floor($n / 100000)/10;
    $suffix = 'm';
  }

  return $n_format . $suffix;
}
?>