<?php

class cUrl {

	public function fetchUrl($options){

		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $options['url']);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

		if(isset($options['follow'])){
			curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
		}

		curl_setopt($curl, CURLOPT_HEADER, false);
		// curl_setopt($curl, CURLOPT_PROXY, $proxy);
		
		if(strpos($options['url'], 'applenapps') !== false){
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);     
			curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
			curl_setopt($curl, CURLOPT_SSLVERSION , 3);
		}

		if(isset($options['postData'])){
			curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($options['postData']));
		}

		if(isset($options['proxy'])){
			if($options['proxy']){
				// curl_setopt($curl, CURLOPT_PROXY, $options['proxy']);
			}
		}

		if(isset($options['cookie'])){
		    curl_setopt($curl, CURLOPT_COOKIEFILE, getcwd() . '/mirazmac_cookie.txt'); // The cookie file
			curl_setopt($curl, CURLOPT_COOKIEJAR, getcwd() . '/mirazmac_cookie.txt'); // cookie jar
		}
		
		$data = curl_exec($curl);
		$info = curl_getinfo($curl);
		$httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);

		if($errno = curl_errno($curl)) {
			$error_message = curl_strerror($errno);
			var_dump($options['url'])."\r\n";
    		echo "cURL error ({$errno}):\n {$error_message}";
    		echo "\r\n";
    		echo "\r\n";
		}

		curl_close($curl);

		/* If the document has loaded successfully without any redirection or error */
		if ($httpCode >= 200 && $httpCode < 300) {
			return $data;
		}

		return false;
		
	}

}

?>