<?php

ini_set('display_errors', 1);
define('DEBUG', false);

/**
* Return the information from the lookup api
*/
class LookUp extends cUrl {

	public $proxyOn = false;
	public $cacheOn = false;
	public $debug = true;

	private $platforms = array(
		'mac-software' => 'macos',
		'software'     => 'iphone'
	);

	public $aliasCategories = array(
		12001 => 6000,
		12021 => 6001,
		12019 => 6002,
		12018 => 6003,
		12017 => 6004,
		12016 => 6005,
		12015 => 6006,
		12014 => 6007,
		12012 => 6009,
		12011 => 6011,
		12008 => 6012,
		12007 => 6013,
		12006 => 6014,
		12005 => 6015,
		12004 => 6016,
		12003 => 6017,
		12010 => 6020,
		12201 => 7001,
		12202 => 7002,
		12203 => 7003,
		12204 => 7004,
		12205 => 7005,
		12206 => 7006,
		12207 => 7007,
		12208 => 7008
	);

	/**
	 * @var cacheFolder
	 */
	private $cacheFolder = '';

	/**
	 * Description
	 * @return type
	 */
	public function __construct(){}

	/**
	 * Return a json object with the information for given song
	 * @param int $id
	 * @param string $country, default us
	 * @return array
	 */
	public function getSongInfo($id, $country = 'us'){
		return $this->getInfo(array('id' => $id, 'type' => 'song', 'country' => $country));
	}

	/**
	 * Return a json object with the information for given search term
	 * @param string $term
	 * @param string $country, default us
	 * @return array
	 */
	public function searchForSong($term, $country = 'us'){
		return $this->searchItem(array('term' => $term, 'entity' => 'song', 'country' => $country));
	}

	/**
	 * Return a json object with the information for given ebook
	 * @param int $id
	 * @param string $country, default us
	 * @return array
	 */
	public function getEBookInfo($id, $country = 'us'){
		return $this->getInfo(array('id' => $id, 'type' => 'ebook', 'country' => $country));
	}

	public function getArtistApps($artistID, $country = 'us'){
		return $this->getInfo(array('id' => $artistID, 'type' => 'software', 'country' => $country));
	}

	public function getArtistInfo($artistID, $country = 'us'){
		return $this->getInfo(array('id' => $artistID, 'type' => 'software', 'country' => $country));
	}

	/**
	 * Return a json object with the information for given app
	 * @param int $id
	 * @param string $country, default us
	 * @return array
	 */

	public function getAppInfo($id, $country = 'us'){
		return $this->getInfo(array('id' => $id, 'type' => 'software', 'country' => $country));
	}

	/**
	 * Return a cleaned array with the information for given ebook
	 * @param type $json 
	 * @return type
	 */
	public function ebookCleanUp($json){

		return array(
			'storeID'               => $this->isValueSet($json->results[0]->trackId),
			'title'                 => $this->isValueSet($json->results[0]->trackName),
			'url'                   => $this->isValueSet($json->results[0]->trackViewUrl),
			'description'           => $this->isValueSet($json->results[0]->description),
			'cover512'              => $this->isValueSet($json->results[0]->artworkUrl512),
			'cover100'              => $this->isValueSet($json->results[0]->artworkUrl100),
			'cover150'              => $this->isValueSet($json->results[0]->artworkUrl60),
			'genres'                => $this->isValueSet($json->results[0]->genres),
			'genreIds'              => $this->isValueSet($json->results[0]->genreIds),
			'size'                  => $this->isValueSet($json->results[0]->fileSizeBytes),
			'released'              => $this->isValueSet($json->results[0]->releaseDate),
			'price'                 => $this->isValueSet($json->results[0]->price),
			'currency'              => $this->isValueSet($json->results[0]->currency),
			'free'                  => $this->isValueSet($json->results[0]->price) ? 1 : 0,
			'developerId'           => $this->isValueSet($json->results[0]->artistId),
			'developer'             => $this->isValueSet($json->results[0]->artistName),
			'developerUrl'          => $this->isValueSet($json->results[0]->artistViewUrl),
			'score'                 => $this->isValueSet($json->results[0]->averageUserRating),
			'reviews'               => $this->isValueSet($json->results[0]->userRatingCount),
		);

	}

	/**
	 * Return a cleaned array with the information for given song
	 * @param json $json 
	 * @return array
	 */
	public function songCleanUp($json){

		$songID = '';
		$albumID = '';
		$urlTitle = '';
		if(isset($json->trackViewUrl)){

			preg_match('/\/album\/(.*?)\/(.*?)\?i=(.*?)&uo=/is', $json->trackViewUrl, $matches);
			if(isset($matches[1])){
				$urlTitle = $matches[1];
			}

			if(isset($matches[2])){
				$albumID = $matches[2];
			}

			if(isset($matches[3])){
				$songID = $matches[3];
			}
		}

		return array(
			'songID'                => $json->trackId,
			'songName'              => $json->trackName,
			'collectionName'        => $json->collectionName,
			'trackViewUrl'          => $json->trackViewUrl,
			'urlTitle'              => $urlTitle,
			'albumID'               => $albumID,
			'artworkUrl30'          => $json->artworkUrl30,
			'artworkUrl60'          => $json->artworkUrl60,
			'artworkUrl100'         => $json->artworkUrl100,
			'_songID'               => $songID
		);
	}

	/**
	 * Return a cleaned array with the information for given app
	 * @param type $json 
	 * @return type
	 */
	public function appCleanUp($json){

		$urlTitle = '';
		if(isset($json->trackViewUrl)){
			preg_match('/\/app\/(.*?)\/id/is', $json->trackViewUrl, $matches);
			if(isset($matches[1])){
				$urlTitle = $matches[1];
			}
		}

		$icon = '';
		if(isset($json->artworkUrl512)){
			// $icon = str_replace('512x512bb', 'sizeXsizebb', $json->artworkUrl512);
			$icon = $json->artworkUrl512;
		} else if(isset($json->artworkUrl100)){
			// $icon = str_replace('100x100bb', 'sizeXsizebb', $json->artworkUrl100);
			$icon = $json->artworkUrl100;
		} else if(isset($json->artworkUrl160)){
			// $icon = str_replace('160x160bb', 'sizeXsizebb', $json->artworkUrl160);
			$icon = $json->artworkUrl160;
		}

		$kindConverted = $this->convertKind($json);

		$developerUrlTitle = '';
		if(isset($json->artistViewUrl)){
			preg_match('/\/developer\/(.*?)\/id/is', $json->artistViewUrl, $matches);
			if(isset($matches[1])){
				$developerUrlTitle = $matches[1];
			}
		}

		return array(
			'storeID'               => $this->isValueSet($json->trackId),
			'bundleId'              => $this->isValueSet($json->bundleId),
			'title'                 => $this->isValueSet($json->trackName),
			'urlTitle'              => $urlTitle,
			'url'                   => $this->isValueSet($json->trackViewUrl),
			'description'           => $this->isValueSet($json->description),
			'icon'               	=> $icon,
			'icon512'               => $this->isValueSet($json->artworkUrl512),
			'icon100'               => $this->isValueSet($json->artworkUrl100),
			'icon160'               => $this->isValueSet($json->artworkUrl60),
			'genres'                => $this->isValueSet($json->genres),
			'genreIds'              => $this->isValueSet($json->genreIds),
			'primaryGenre'          => $this->isValueSet($json->primaryGenreName),
			'primaryGenreId'        => $this->isValueSet($json->primaryGenreId),
			'contentRating'         => $this->isValueSet($json->contentAdvisoryRating),
			'languages'             => $this->isValueSet($json->languageCodesISO2A),
			'size'                  => $this->isValueSet($json->fileSizeBytes),
			'requiredOsVersion'     => $this->isValueSet($json->minimumOsVersion),
			'released'              => $this->isValueSet($json->releaseDate),
			'updated'               => $this->isValueSet($json->currentVersionReleaseDate),
			'releaseNotes'          => $this->isValueSet($json->releaseNotes),
			'version'               => $this->isValueSet($json->version),
			'price'                 => $this->isValueSet($json->price),
			'currency'              => $this->isValueSet($json->currency),
			'features'              => $this->isValueSet($json->features),
			'kind'              	=> $this->isValueSet($json->kind),
			'kindConverted'         => $kindConverted,
			'free'                  => isset($json->price) ? 1 : 0,
			'developerId'           => $this->isValueSet($json->artistId),
			'developer'             => $this->isValueSet($json->artistName),
			'developerUrl'          => $this->isValueSet($json->artistViewUrl),
			'developerUrlTitle'     => $developerUrlTitle,
			'developerWebsite'      => $this->isValueSet($json->sellerUrl),
			'score'                 => $this->isValueSet($json->averageUserRating),
			'reviews'               => $this->isValueSet($json->userRatingCount),
			'currentVersionScore'   => $this->isValueSet($json->averageUserRatingForCurrentVersion),
			'currentVersionReviews' => $this->isValueSet($json->userRatingCountForCurrentVersion),
			'screenshots'           => $this->isValueSet($json->screenshotUrls),
			'ipadScreenshots'       => $this->isValueSet($json->ipadScreenshotUrls),
			'appletvScreenshots'    => $this->isValueSet($json->appletvScreenshotUrls),
			'supportedDevices'      => $this->isValueSet($json->supportedDevices),
			'advisories'      		=> $this->isValueSet($json->advisories)
		);

	}

	/**
	 * Description
	 * @param type &$value 
	 * @param type|string $default 
	 * @return string|int
	 */
	private function isValueSet(&$value, $default = ''){
		return isset($value) ? $value : $default;
	}

	/**
	 * Return a json object with information
	 * @param type $options 
	 * @return json|bool
	 */
	public function setProxyFile($path){
		$this->proxyFile = $path;
	}

	/**
	 * Return a json object with information
	 * @param type $options 
	 * @return json|bool
	 */
	public function setProxyManagerFile($path){
		$this->proxyManagerFile = $path;
	}

	/**
	 * Return a json object with information
	 * @param type $options 
	 * @return json|bool
	 */
	private function getCurrentProxy(){
		$currentIP = 0;
		$currentIP = (int) file_get_contents($this->proxyManagerFile);

		$indexIP = $currentIP;
		$currentIP += 1;

		if($currentIP > $this->countProxies){
			// reset
			file_put_contents($this->proxyManagerFile, '0');
		} else {
			file_put_contents($this->proxyManagerFile, $currentIP);
		}

		return $this->proxies[$indexIP];

	}

	/**
	 * Return a json object with information
	 * @param type $options 
	 * @return json|bool
	 */
	public function proxiesInit(){
		$proxies = file_get_contents($this->proxyFile);
		$this->proxies = explode(',', $proxies);
		$this->countProxies = count($this->proxies) - 1;
	}

	/**
	 * Return a json object with information
	 * @param type $options 
	 * @return json|bool
	 */
	public function fetchUrlExtend($options){

		$proxyData = false;
		if($this->proxyOn){
			$proxyData = $this->getCurrentProxy();
			$options['proxy'] = $proxyData;
		}

		return $this->fetchUrl($options);

	}

	/**
	 * Return a json object with information
	 * @param type $options 
	 * @return json|bool
	 */
	private function getInfo($options){

		if (empty($options['id']) && empty($options['bundleId'])) {
			die('Either id or bundleId is required');
		}

		$idField = !empty($options['id']) ? 'id' : 'bundleId';
    	$idValue = !empty($options['id']) ? $options['id'] : $options['bundleId'];
    	$country = !empty($options['country']) ? $options['country'] : 'us';

		$lookUpUrl = 'https://itunes.apple.com/lookup?'.$idField.'='.$idValue.'&entity='.$options['type'].'&country='.$country;
		// set the cache file name
		$cacheFileName = $this->cacheFolder.'/'.$options['type'].'/'.$idValue.'.js';

		if (!file_exists($this->cacheFolder.'/'.$options['type'].'/')) {
    		mkdir($this->cacheFolder.'/'.$options['type'].'/', 0777, true);
		}

		if(file_exists($cacheFileName)){

			// fetch cache data 
			$jsonData = file_get_contents($cacheFileName);

			// decode
			$objectData = json_decode($jsonData);

		} else {

			// get the json data
			$jsonData = $this->fetchUrlExtend(array('url' => $lookUpUrl));
			if($jsonData){

				// decode
				$objectData = json_decode($jsonData);

				if (json_last_error() !== JSON_ERROR_NONE) {
					return false;
				}

				if(!isset($objectData->resultCount)){
					return false;
				}

				if($objectData->resultCount == 0){
					return false;
				}

				if($objectData === null){
					return false;
				}

				if($this->cacheOn){
					// save the json data
					file_put_contents($cacheFileName, $jsonData);
				}

			}

		}

		// check if array is empty
		if(!empty($objectData)){
			if(DEBUG){
				prettyPrint($objectData);
				die;
			}
			return $objectData;
		}

		return false;

	}

	/**
	 * Return a json object with information
	 * @param type $options 
	 * @return json|bool
	 */
	private function searchItem($options){

		if (empty($options['term']) && empty($options['entity'])) {
			die('Either `id` or `entity` is required');
		}

		$term = $options['term'];
    	$country = $options['country'];
    	$entity = $options['entity'];

		$searchUrl = 'https://itunes.apple.com/search?term='.$term.'&entity='.$entity.'&country='.$country;
		
		if($cacheOn){

			// set the cache file name
			$cacheFileName = $this->cacheFolder.'/'.$options['type'].'/search/'.$term.'.js';

			if (!file_exists($this->cacheFolder.'/'.$options['type'].'/search/')) {
	    		mkdir($this->cacheFolder.'/'.$options['type'].'/search/', 0777, true);
			}
		}

		if(file_exists($cacheFileName)){

			// fetch cache data 
			$jsonData = file_get_contents($cacheFileName);

			// decode
			$objectData = json_decode($jsonData);

		} else {

			// get the json data
			$jsonData = $this->fetchUrlExtend(array('url' => $searchUrl));
			if($jsonData){

				// decode
				$objectData = json_decode($jsonData);

				if (json_last_error() !== JSON_ERROR_NONE) {
					return false;
				}

				if(!isset($objectData->resultCount)){
					return false;
				}

				if($objectData->resultCount == 0){
					return false;
				}

				if($objectData === null){
					return false;
				}

				if($this->cacheOn){
					// save the json data
					file_put_contents($cacheFileName, $jsonData);
				}

			}

		}

		// check if array is empty
		if(!empty($objectData)){
			if(DEBUG){
				prettyPrint($objectData);
				die;
			}
			return $objectData;
		}

		return false;

	}

	/**
	 * Description
	 * @param arraay $array 
	 */
	public function prettyPrint($array){
		echo '<pre>'.print_r($array, true).'</pre>';
	}

	/**
	 * Set cache folder
	 * @param string $path 
	 */
	public function setCacheFolder($path){
		$this->cacheFolder = $path;
	}

	/**
	 * Convert kind
	 * @param jsonObject $json 
	 * @return string
	 */
	public function convertKind($json){

		if($this->isValueSet($json->features[0]) == 'iosUniversal'){
			return 'universal';
		} else {

			if (!is_null($this->isValueSet($json->screenshotUrls[0], NULL))) {
				return $this->platforms[$json->kind];
			}
			
			return 'ipad';
		}

	}

}

?>